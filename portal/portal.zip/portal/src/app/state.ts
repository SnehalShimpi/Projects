export class State{

    state : String; 
}