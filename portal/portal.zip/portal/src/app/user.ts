export  interface User  
{firstName : String;
  lastName  : String;
  birthDate : String;
  gender    : String;
  hobbies   : String;
  phoneNo   : String;
  address   : String;
  city      : String;
  state     : String;
  zipCode   : String;  
  email     : String;
  password  : String;
  confirmPassword : String;
  userName : String;
  profPic : String;
}
export interface Uservalue {
  [key : number] : User
}