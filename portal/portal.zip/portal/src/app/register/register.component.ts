import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { MustMatch } from '../validate';
import { UserService } from '../user.service';
import { User } from '../user';
import { State } from '../state';
import { ToastrService } from 'ngx-toastr';
import { devModeEqual } from '@angular/core/src/change_detection/change_detection';
import { variable } from '@angular/compiler/src/output/output_ast';

class imageSnippet{
 
  constructor(public src:string, public file : File ){}
}
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {
  selectedFile :imageSnippet;
  userForm: FormGroup;
  user: User[];
  state: State[];
  public Image :any


  constructor(private fb: FormBuilder, private userService: UserService, private t: ToastrService) { }
  
   
  
  ngOnInit() {
    this.list();
    this.getState();
    //this.t.success('value', 'updated');

    this.userForm = this.fb.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      birthdate: ['', Validators.required],
      gender: ['', Validators.required],
      hobby: [''],
      phoneNo: ['', [Validators.required, Validators.maxLength(10), Validators.minLength(10)]],
      address: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      zipcode: ['', [Validators.required, Validators.maxLength(6), Validators.minLength(6),Validators.pattern('^[0-9]*$')]],
      email: ['', [Validators.required, Validators.email]],

      password: ['', [Validators.required, Validators.pattern('^(?=.*[a-z])(?=.*[A-Z])(?=.*)(?=.*[#$^+=!*()@%&]).{4,8}$')]],
      confirmPassword: ['', Validators.required],
      username: ['', [Validators.required, Validators.pattern('^[a-z]*$')]],
      ProfPic : ['',Validators.required],
    }, { validator: MustMatch('password', 'confirmPassword')}
    )}

  
  onSubmit() {
  
  }

    ProcessFile(imageInput :any){
     this.Image = imageInput;  
     const file : File = this.Image.files[0];
     const reader = new FileReader();
       reader.addEventListener('load',(event : any)=>{
    
      this.selectedFile = new imageSnippet(event.target.result,file)
      this.userService.uploadImage(this.selectedFile.file).subscribe(
        (res) => {
         console.log(res);
         console.log(res.message)
         console.log(res.err)
         console.log()
         if(res.status == true){
           this.t.success(res.message);
         }
         if(res.status == false){
           this.t.error(res.err)
         }
      
        },
        (err) => {
          console.log(err);
       
        })
       
    
    
     });
     reader.readAsDataURL(file);
    
  }
 list() {
    this.userService.getList().subscribe((data: any) => {
      this.user = data.docs;
      //console.log(data);
      
    })
  }

  add() { 
    
      this.userService.add(this.userForm.value).subscribe((res : any) =>{
        console.log(this.userForm.value);
       
        console.log(res);
      if(res.status == 1){
        this.t.error('status', 'Email already in use');
      }
      if(res.status == 2){
        this.t.error('error','username in use')
      }
    },
      (err) => {
              console.log(err);
      })
     
     

      
   
  }

  getState() {
    this.userService.getState().subscribe((data: any) => {
      this.state = data.docs;
     
    })


  }
 
      
 
}
