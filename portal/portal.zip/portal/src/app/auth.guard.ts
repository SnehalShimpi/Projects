import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import{UserService} from './user.service';
@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      //this.T.error('Permission denied', "Please login");
      if(this.auth.isLoggedIn == false){
        this.T.error("Please Log In");
      }
    return this.auth.isLoggedIn;
  
    
  }
  constructor(private T : ToastrService , private auth : UserService){

  }
}
