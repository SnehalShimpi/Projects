import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import{UserService} from '../user.service';
import { ToastrService } from 'ngx-toastr';
import { User } from '../user';
import{Router,RouterModule} from '@angular/router'; 
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  user : User[];
  constructor(private fb : FormBuilder,private userService : UserService,
    private T : ToastrService,
    private router : Router) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      username : ['', Validators.required],
      password : ['', Validators.required],
      
  });
  
}
login(){
this.userService.login(this.loginForm.value).subscribe((res : any) => {
  this.user = res.status;
  console.log("Im user : "+this.user);
if(res.status == true){
  console.log("login done")
  this.T.success('status', "Login Succesfully Done");
  this.router.navigateByUrl('dashboard');
  this.userService.setLoggedIn(true);
}else{
  console.log("not done");
  this.T.error('status', "Login failed");
}
});
}
}
