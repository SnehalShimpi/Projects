import { Injectable } from '@angular/core';
import { Observable, of, observable } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';
import { User } from './user';
import { ToastrService } from 'ngx-toastr';



@Injectable({
  providedIn: 'root'
})
export class UserService {
 
  private LoggedInStatus = false;

  url = "http://localhost:8080/secure/users/";
  url1 = "http://localhost:8080/secure/user/";
  stateUrl = "http://localhost:8080/secure/states/";
  loginUrl ="http://localhost:8080/secure/login/";
  forgotPassword = "http://localhost:8080/secure/mail/";
  resetPassword = "http://localhost:8080/secure/password/";
  profPicture = "http://localhost:8080/secure/upload"
  
 // validate = "http://localhost:8080/secure/users/validate/";
  constructor(private http: HttpClient , private t : ToastrService) { }

   setLoggedIn(value : boolean){
      this.LoggedInStatus = value;
  }

  get isLoggedIn(){
    return this.LoggedInStatus;
  }
  add(data) {
    console.log(name);
    return this.http.post<any>(this.url1, data);
   
  }

  getList() {
    return this.http.get(`${this.url}`);
  }

  getState()
  {
    return this.http.get(`${this.stateUrl}`);
  }

 login(data)
 {
   return this.http.post<any>(`${this.loginUrl}`,data);
 }

 forgotPass(data){
   return this.http.post<any>(`${this.forgotPassword}`, data);
 }

 ResetPass(email , pass){
   return this.http.put<any>(`${this.resetPassword}`, {"email" : email , "password" : pass });
 }

 ProfPic(ProfPic, value){
   return this.http.post<any>(`${this.profPicture}`, {"KEY" : ProfPic, "VALUE" : value})
 }
 public uploadImage(image:File){
  const formData = new FormData();
  formData.append('photo',image);
  return this.http.post<any>('http://localhost:8080/secure/upload',formData)
}


}

