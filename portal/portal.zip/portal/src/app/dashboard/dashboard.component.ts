import { Component, OnInit } from '@angular/core';
import{UserService} from '../user.service';
import { ToastrService } from 'ngx-toastr';
import { User } from '../user';
import{Router,RouterModule} from '@angular/router'; 
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private userService : UserService,
    private T : ToastrService,
    private router : Router) { }

  ngOnInit() {
  }
  
  login()
  {
    console.log("inside login");
    this.router.navigateByUrl('dashboard');
    this.userService.setLoggedIn(true);
    this.T.success("redirected to same page");
  }

}
